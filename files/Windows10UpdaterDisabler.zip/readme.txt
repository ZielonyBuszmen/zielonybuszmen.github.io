Windows Update Disabler Service

Created by PainteR, 2016
Many thanks to Tihiy
Get it here: http://winaero.com/blog/windows-10-update-disabler-disables-windows-10-updates-reliably

If you are familiar with unexpected reboots of Windows 10 or too short battery standing time, then this is specially for you!

Windows Update Disabler is a simple service made for my personal needs. It disables the update installation in Windows 10.

You might be curious how it is differs from other similar apps like OOSU10?

1. It does not rely on Registry values which the operating system can overwrite one day without your asknowledge (like it happens to me).
2. It disabled all scheduled tasks and Windows Update on the user login.
3. It uses an undocumented system call to check the current state of Windows Update and tries to terminate it immediately.
4. It does not require a reboot, i.e. it work on-the-fly


PS: The app was not tested enough in public.

How to setup the app

1. Copy the file to a desired folder.
2. Open an elevated command prompt in that folder.
3. Type or paste the following command
UpdaterDisabler -install


How to remove the app
1. Open an elevated command prompt in the folder you have UpdaterDisabler.exe.
2. Type or paste the following command
UpdaterDisabler -remove

